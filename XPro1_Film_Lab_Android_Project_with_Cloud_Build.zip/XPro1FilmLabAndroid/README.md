# XPro1 Film Lab — Android Mobile Darkroom

A native Android/Jetpack Compose port of the XPro1 Film Lab project. The app bundles the existing Film Recipes and My Presets JSON libraries, including Kodak Gold 200, and works offline after installation.

## Build an APK in the cloud (no Android SDK needed on your phone)

This project includes `.github/workflows/android.yml` to build a debug APK with GitHub Actions.

1. Create a new GitHub repository from your phone and upload the contents of this folder (the files inside `XPro1FilmLabAndroid`, not the enclosing folder).
2. Open the repository's **Actions** tab and select **Build XPro1 Film Lab APK**.
3. Tap **Run workflow**. Wait for the run to finish successfully.
4. Open that completed run and download the artifact named **XPro1-Film-Lab-debug-apk**.
5. Extract the ZIP on Android, tap `app-debug.apk`, and allow installation from that source if Android asks.

The workflow builds with JDK 17, Android SDK, and Gradle on GitHub's hosted runner. The APK is a debug build and is suitable for personal installation/testing; it is not a Play Store release-signed package.

## Local build

Open this folder in Android Studio (Ladybug or newer), sync Gradle, then run `gradle assembleDebug` or use **Build → Build APK(s)**. Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Current port status / limitations

- Native Android UI; no Tkinter dependency.
- Uses Android's system photo picker for JPEG/PNG and other Android-decodable image formats.
- JPEG export saves to `Pictures/XPro1 Film Lab` at the source image dimensions.
- Film Recipes and My Presets are separate tabs and loaded from the original JSON libraries.
- Preview is resized for performance; export renders at original dimensions.
- The Kotlin renderer is an approximation of the Python engine, not a bit-for-bit port of NumPy/Pillow processing.
- Fujifilm RAF decoding is not implemented. RAF support is not advertised; convert RAF to JPEG/DNG before importing.
- Some advanced camera recipe settings are displayed as metadata and are not yet individually editable.

## App details

- App name: XPro1 Film Lab
- Application ID: `com.xpro1filmlab`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- Offline processing; no account required.
