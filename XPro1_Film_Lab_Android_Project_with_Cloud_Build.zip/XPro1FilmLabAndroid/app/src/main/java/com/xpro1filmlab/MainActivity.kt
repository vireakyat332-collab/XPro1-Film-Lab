package com.xpro1filmlab

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale
import kotlin.math.*
import kotlin.random.Random

private data class FilmPreset(val name: String, val base: String, val params: JSONObject, val look: JSONObject, val fuji: JSONObject, val group: String)

class MainActivity : ComponentActivity() {
    private var source by mutableStateOf<Bitmap?>(null)
    private var rendered by mutableStateOf<Bitmap?>(null)
    private var selected by mutableStateOf<FilmPreset?>(null)
    private var allPresets = listOf<FilmPreset>()
    private var busy by mutableStateOf(false)
    private var tab by mutableStateOf("Film Recipes")
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) loadImage(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        allPresets = loadPresets()
        selected = allPresets.firstOrNull { it.name.equals("Kodak Gold 200", true) } ?: allPresets.firstOrNull()
        setContent { FilmLabScreen() }
    }

    private fun loadPresets(): List<FilmPreset> {
        val out = mutableListOf<FilmPreset>()
        fun readFolder(folder: String, group: String) {
            assets.list(folder)?.filter { it.endsWith(".json") }?.forEach { file ->
                runCatching {
                    val j = JSONObject(assets.open("$folder/$file").bufferedReader().use { it.readText() })
                    out += FilmPreset(j.optString("name", file.removeSuffix(".json")), j.optString("base", "Provia"), j.optJSONObject("params") ?: JSONObject(), j.optJSONObject("look") ?: JSONObject(), j.optJSONObject("fuji_camera_settings") ?: JSONObject(), group)
                }
            }
        }
        readFolder("film_recipes", "Film Recipes")
        readFolder("my_presets", "My Presets")
        return out.sortedBy { it.name.lowercase(Locale.ROOT) }
    }

    private fun loadImage(uri: Uri) {
        lifecycleScope.launch {
            busy = true
            val bmp = withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } }
            source = bmp
            render()
        }
    }

    private fun render() {
        val input = source ?: return
        val preset = selected ?: return
        lifecycleScope.launch {
            busy = true
            rendered = withContext(Dispatchers.Default) {
                val scale = min(1.0, 1700.0 / max(input.width, input.height))
                val w = max(1, (input.width * scale).roundToInt()); val h = max(1, (input.height * scale).roundToInt())
                val small = Bitmap.createScaledBitmap(input, w, h, true)
                FilmRenderer.apply(small, preset)
            }
            busy = false
        }
    }

    private fun export() {
        val input = source ?: return
        val preset = selected ?: return
        lifecycleScope.launch {
            busy = true
            val full = withContext(Dispatchers.Default) { FilmRenderer.apply(input, preset) }
            withContext(Dispatchers.IO) {
                val values = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, "XPro1_${preset.name.replace(' ', '_')}.jpg"); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg"); put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/XPro1 Film Lab") }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) contentResolver.openOutputStream(uri)?.use { full.compress(Bitmap.CompressFormat.JPEG, 96, it) }
            }
            busy = false
        }
    }

    @Composable private fun FilmLabScreen() {
        val dark = Color(0xFF101512); val panel = Color(0xFF1A241E); val green = Color(0xFF57C58A)
        MaterialTheme(colorScheme = darkColorScheme(primary = green, background = dark, surface = panel, onSurface = Color(0xFFE8F0EA))) {
            Column(Modifier.fillMaxSize().background(dark).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("XPRO1  FILM LAB", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp); Text("MOBILE DARKROOM", color = green, fontSize = 10.sp, letterSpacing = 2.sp) }
                    FilledTonalButton(onClick = { pickImage.launch("image/*") }) { Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(6.dp)); Text("Open") }
                }
                Row(Modifier.fillMaxWidth().height(250.dp).background(Color(0xFF080B09), RoundedCornerShape(18.dp)), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                    val preview = rendered
                    if (preview != null) Image(preview.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
                    else Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.PhotoCameraBack, null, tint = green, modifier = Modifier.size(44.dp)); Text("Open a photo to start", color = Color.LightGray) }
                    if (busy) CircularProgressIndicator(Modifier.size(28.dp), color = green, strokeWidth = 2.dp)
                }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Film Recipes", "My Presets", "Settings").forEach { label ->
                        FilterChip(selected = tab == label, onClick = { tab = label }, label = { Text(label) })
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { export() }, enabled = source != null && !busy) { Icon(Icons.Default.SaveAlt, null); Text("Export") }
                }
                when (tab) {
                    "Settings" -> SettingsPanel()
                    else -> PresetPanel(tab)
                }
            }
        }
    }

    @Composable private fun PresetPanel(group: String) {
        val items = allPresets.filter { it.group == group }
        Column(Modifier.fillMaxSize()) {
            Text("${items.size} looks", color = Color(0xFF8FA99A), fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(items) { item ->
                    val active = selected?.name == item.name && selected?.group == item.group
                    Surface(color = if (active) Color(0xFF294333) else Color(0xFF1A241E), shape = RoundedCornerShape(12.dp), onClick = { selected = item; render() }) {
                        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(item.name, color = Color.White, fontWeight = FontWeight.SemiBold); Text(item.base, color = Color(0xFF8FA99A), fontSize = 11.sp) }
                            if (active) Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF57C58A)) else Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }

    @Composable private fun SettingsPanel() {
        val p = selected
        if (p == null) { Text("Choose a recipe first", color = Color.White); return }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Text("ACTIVE LOOK", color = Color(0xFF57C58A), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(p.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Film settings are loaded from the selected recipe. Choose another look in the recipe tabs to compare.", color = Color.LightGray, fontSize = 13.sp)
            listOf("film_simulation", "dynamic_range", "highlight", "shadow", "color", "sharpness", "clarity", "high_iso_nr", "white_balance", "grain_roughness", "grain_size", "color_chrome_effect", "color_chrome_fx_blue", "smooth_skin_effect", "infrared_filter").forEach { key ->
                val value = p.fuji.optString(key, p.params.optString(key, "Default"))
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(key.replace('_',' ').replaceFirstChar { it.uppercase() }, color = Color(0xFFDDE8DF)); Text(value, color = Color(0xFF8BD4A8)) }
                HorizontalDivider(color = Color(0xFF29362E))
            }
            Text("Tip: use full-resolution export for final JPEGs. Preview is resized for smooth mobile editing.", color = Color(0xFF8FA99A), fontSize = 12.sp, modifier = Modifier.padding(top = 12.dp))
        }
    }
}

private object FilmRenderer {
    fun apply(input: Bitmap, preset: FilmPreset): Bitmap {
        val w = input.width; val h = input.height
        val pixels = IntArray(w * h); input.getPixels(pixels, 0, w, 0, 0, w, h)
        val p = preset.params; val look = preset.look; val fuji = preset.fuji
        val contrast = look.optDouble("contrast", 0.12).toFloat()
        val fade = look.optDouble("fade", 0.0).toFloat()
        val gain = look.optJSONArray("gain")
        val gr = gain?.optDouble(0, 1.0)?.toFloat() ?: 1f; val gg = gain?.optDouble(1, 1.0)?.toFloat() ?: 1f; val gb = gain?.optDouble(2, 1.0)?.toFloat() ?: 1f
        val sat = (1f + p.optDouble("saturation", 0.0).toFloat() / 100f).coerceAtLeast(0f)
        val grain = (p.optDouble("grain", 0.0).toFloat() / 100f).coerceIn(0f, .35f)
        val hi = fuji.optInt("highlight", 0); val sh = fuji.optInt("shadow", 0); val colour = fuji.optInt("color", 0)
        val film = fuji.optString("film_character", "")
        val rnd = Random(7)
        for (i in pixels.indices) {
            val c = pixels[i]; var r = ((c shr 16) and 255) / 255f; var g = ((c shr 8) and 255) / 255f; var b = (c and 255) / 255f
            r = (r * gr).coerceIn(0f,1f); g = (g * gg).coerceIn(0f,1f); b = (b * gb).coerceIn(0f,1f)
            val lum = .2126f*r + .7152f*g + .0722f*b
            val sm = (1f - (lum/.5f).coerceIn(0f,1f)).let { it*it*(3-2*it) }
            val hm = ((lum-.5f)/.5f).coerceIn(0f,1f).let { it*it*(3-2*it) }
            r -= hi*.010f*hm + sh*.010f*sm; g -= hi*.010f*hm + sh*.010f*sm; b -= hi*.010f*hm + sh*.010f*sm
            if (film == "kodak_gold_200") { val curve = (lum-.5f)*(.5f-lum)*.58f; r += curve*.18f + hm*.014f; g += curve*.10f + hm*.006f; b -= hm*.012f; }
            val y = .2126f*r + .7152f*g + .0722f*b
            r = y + (r-y)*sat; g = y + (g-y)*sat; b = y + (b-y)*sat
            val k = (1f + contrast).coerceAtLeast(.1f)
            r = ((r-.5f)*k+.5f)*(1-fade)+fade; g = ((g-.5f)*k+.5f)*(1-fade)+fade; b = ((b-.5f)*k+.5f)*(1-fade)+fade
            if (colour != 0) { val f = 1f + colour*.025f; val yy=.2126f*r+.7152f*g+.0722f*b; r=yy+(r-yy)*f; g=yy+(g-yy)*f; b=yy+(b-yy)*f }
            if (grain > 0f) { val n=(rnd.nextFloat()-.5f)*grain*.42f; r+=n; g+=n; b+=n }
            val rr=(r.coerceIn(0f,1f)*255).roundToInt(); val gg2=(g.coerceIn(0f,1f)*255).roundToInt(); val bb=(b.coerceIn(0f,1f)*255).roundToInt()
            pixels[i] = (c and -0x1000000) or (rr shl 16) or (gg2 shl 8) or bb
        }
        return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    }
}
